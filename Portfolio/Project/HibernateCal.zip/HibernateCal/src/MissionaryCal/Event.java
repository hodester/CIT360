package MissionaryCal;

/**
*
* @author Peter Wong
* @description Calendar Database module for missionary calendar application
* @notes This contain 5 functions which are addEvent, getEvent, updateEvent, removeEvent, and DBConnect
*/

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "eventcalendar")
public class Event {
	private int id;
	private Date date;
	private String name;
	private String email;
	private String phone;
	private String address;
	private String notes;
	
	public Event(){}
	public Event(Date eventDate, String memberName, String memberEmail, String memberPhone, String memberAddress, String notes){
		this.date = eventDate;
		this.name = memberName;
		this.email = memberEmail;
		this.phone = memberPhone;
		this.address = memberAddress;
		this.notes = notes;
	}
	

	public void setId(int id){
		this.id = id;
		
	}
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment", strategy = "increment")
	public int getId(){
		return id;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	@Column(name="eventDate")
	public Date getDate() {
		return date;
	}
	public void setName(String name){
		this.name = name;
	}
	@Column(name="name")
	public String getName() {
		return name;
	}
	public void setEmail(String email){
		this.email = email;
	}
	@Column(name="email")
	public String getEmail() {
		return email;
	}		

	public void setPhone(String phone){
		this.phone = phone;
	}
	@Column(name="phone")
	public String getPhone() {
		return phone;
	}	
	public void setAddress(String address){
		this.address = address;
	}
	@Column(name="address")
	public String getAddress() {
		return address;
	}
	
	public void setNotes(String notes){
		this.notes = notes;
	}
	@Column(name="notes")
	public String getNotes() {
		return notes;
	}		
	
}
