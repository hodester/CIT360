use myhibernatedb;
create table eventcalendar(
 id INT NOT NULL auto_increment,
 eventDate DATETIME default CURRENT_TIMESTAMP,
 name VARCHAR(256) default NULL,
 email VARCHAR(256) default NULL,
 phone VARCHAR(20) default NULL,
 address VARCHAR(256) default NULL,
 notes VARCHAR(512) default NULL,
 PRIMARY KEY (id)
)